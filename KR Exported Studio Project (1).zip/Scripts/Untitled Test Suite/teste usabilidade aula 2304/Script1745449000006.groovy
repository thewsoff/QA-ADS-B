import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.testobject.SelectorMethod

import com.thoughtworks.selenium.Selenium
import org.openqa.selenium.firefox.FirefoxDriver
import org.openqa.selenium.WebDriver
import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium
import static org.junit.Assert.*
import java.util.regex.Pattern
import static org.apache.commons.lang3.StringUtils.join
import org.testng.asserts.SoftAssert
import com.kms.katalon.core.testdata.CSVData
import org.openqa.selenium.Keys as Keys

SoftAssert softAssertion = new SoftAssert();
WebUI.openBrowser('https://www.google.com/')
def driver = DriverFactory.getWebDriver()
String baseUrl = "https://www.google.com/"
selenium = new WebDriverBackedSelenium(driver, baseUrl)
selenium.open("https://www.blazedemo.com/")
selenium.click("name=fromPort")
selenium.select("name=fromPort", "label=S�o Paolo")
selenium.click("name=toPort")
selenium.select("name=toPort", "label=New York")
selenium.click("xpath=(.//*[normalize-space(text()) and normalize-space(.)='destination of the week! The Beach!'])[1]/following::div[1]")
selenium.click("xpath=//input[@value='Find Flights']")
selenium.click("xpath=//input[@value='Choose This Flight']")
selenium.click("id=inputName")
selenium.type("id=inputName", "Flavio")
selenium.click("id=address")
selenium.type("id=address", ("rua abc").toString())
selenium.click("id=city")
selenium.type("id=city", ("S�o Paulo").toString())
selenium.click("id=state")
selenium.type("id=state", "SP")
selenium.click("id=zipCode")
selenium.type("id=zipCode", "123456789")
selenium.click("id=cardType")
selenium.select("id=cardType", "label=Diner's Club")
selenium.click("id=creditCardNumber")
selenium.type("id=creditCardNumber", "1451236598")
selenium.click("id=creditCardMonth")
selenium.type("id=creditCardMonth", "12")
selenium.click("id=creditCardYear")
selenium.type("id=creditCardYear", "2026")
selenium.click("id=nameOnCard")
selenium.type("id=nameOnCard", "Flavio")
selenium.click("xpath=(.//*[normalize-space(text()) and normalize-space(.)='Name on Card'])[1]/following::label[1]")
selenium.click("xpath=//input[@value='Purchase Flight']")
selenium.click("link=home")
