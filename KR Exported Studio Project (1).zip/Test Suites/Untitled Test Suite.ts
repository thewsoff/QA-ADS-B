<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Untitled Test Suite</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>6b884461-8b30-4091-9d6f-7f5dc3f1fd8b</testSuiteGuid>
   <testCaseLink>
      <guid>aba079c4-d103-4b57-8dae-b854d0893351</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Untitled Test Suite/teste usabilidade aula 2304</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
    